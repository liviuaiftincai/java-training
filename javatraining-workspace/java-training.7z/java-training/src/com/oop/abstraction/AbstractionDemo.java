package com.oop.abstraction;

import java.io.IOException;

public class AbstractionDemo {

	public static void main(String[] args) {
		String[] array = {"H", "D", "T", "A", "C", "G"};
		
//		ArraySearch arraySearch = new ArraySearch();
		
		ArraySearch arraySearch = new ArrayBinarySearch();
		arraySearch.setArray(array);
		arraySearch.setKey("C");
		arraySearch.search();
	}
	
}
