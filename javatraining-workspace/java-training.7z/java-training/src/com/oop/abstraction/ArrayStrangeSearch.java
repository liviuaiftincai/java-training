package com.oop.abstraction;

public class ArrayStrangeSearch extends ArraySearch {

	@Override
	public void search() {
		// TODO Auto-generated method stub
		
	}

}
