package com.oop.encapsulation;

public enum Gender {
	
	MALE, FEMALE
	
}
