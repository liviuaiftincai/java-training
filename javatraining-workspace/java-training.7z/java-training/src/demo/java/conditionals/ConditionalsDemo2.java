package demo.java.conditionals;

public class ConditionalsDemo2 {

	public static void main(String[] args) {
		String text = "Hello";
		
		if (text.length() == 5) {
			System.out.println("The condition was TRUE");
		} else {
			System.out.println("The condition was FALSE");
		}
	}
	
}
