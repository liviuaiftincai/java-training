package demo.java.methods;

public class TestMethods {

	public static void main(String[] args) {
		// try it also with static methods
		MethodsDemo demo = new MethodsDemo();
		demo.doSomething("Hello", 5);
	}
	
}
