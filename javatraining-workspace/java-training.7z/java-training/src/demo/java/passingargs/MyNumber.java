package demo.java.passingargs;

public class MyNumber {

	public int number;
	
	public MyNumber(int inputNumber) {
		number = inputNumber;
	}
	
}
