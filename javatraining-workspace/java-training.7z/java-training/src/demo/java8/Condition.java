package demo.java8;

@FunctionalInterface
public interface Condition {

	boolean test(Person person);
	
}
