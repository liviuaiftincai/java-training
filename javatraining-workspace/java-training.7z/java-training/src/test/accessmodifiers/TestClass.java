package test.accessmodifiers;

import demo.java.passingargs.MyNumber;

public class TestClass {

	public static void main(String[] args) {
		MyNumber myNumber = new MyNumber(5);
		System.out.println(myNumber.number);
	}
	
}
